<footer class="main-footer">
    <strong>Copyright &copy; 2023-2025 <a href="https://cahyatech.com">Dian Muhammad Nurcahya</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 2.0
    </div>
</footer>
<?php /**PATH C:\WEBSITE_PROJECT\REMEDY\FormTemplateRemedy\www\resources\views/partials/footer.blade.php ENDPATH**/ ?>