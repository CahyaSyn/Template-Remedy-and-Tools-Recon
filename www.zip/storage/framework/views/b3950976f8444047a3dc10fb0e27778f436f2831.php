<style>
    /* responsive table preview with scroll x */
    .tb_preview {
        width: 100%;
        overflow-x: auto;
        overflow-y: auto;
        display: block;
        white-space: nowrap;
        height: 500px;
    }
</style>
<section class="content py-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Preview Updated Data</h3>
                        <table class="table tb_preview">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($cell); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <form action="<?php echo e(route('tools.download')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <button type="submit">Download Updated File</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\WEBSITE_PROJECT\REMEDY\FormTemplateRemedy\www\resources\views/preview.blade.php ENDPATH**/ ?>